const Command = require("../../abstract/command");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = class AntiMention extends Command {
  constructor(...args) {
    super(...args, {
      name: "antimention",
      aliases: ["mentionblock"],
      description:
        "Create an Anti-Mention AutoMod rule with a custom block message",
      usage: ["antimention enable"],
      category: "Moderation",
      userPerms: ["Administrator"],
      botPerms: ["ManageGuild"],
      guildOnly: true,
    });
  }

  async run({ message, args }) {
    if (
      !message.member.permissions.has(PermissionsBitField.Flags.Administrator)
    ) {
      return message.reply(
        "❌ You need **Administrator** permissions to use this command."
      );
    }

    try {
      await message.guild.autoModerationRules.create({
        name: "Anti-Mention",
        creatorId: message.author.id,
        enabled: true,
        eventType: 1, // MESSAGE_SEND
        triggerType: 5, // MENTION_SPAM
        triggerMetadata: {
          mentionTotalLimit: 5, // Max allowed mentions before block
        },
        actions: [
          {
            type: 1, // BLOCK_MESSAGE
            metadata: {
              customMessage:
                "🚫 Please avoid mass-mentioning users in this server.",
            },
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setColor("#5FFD0A")
        .setDescription("✅ **Anti-Mention** rule created successfully!");
      return message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      return message.channel.send(
        "❌ Failed to create **Anti-Mention** rule. Check my permissions and try again."
      );
    }
  }

  async exec({ interaction }) {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      )
    ) {
      return interaction.reply({
        content:
          "❌ You need **Administrator** permissions to use this command.",
        ephemeral: true,
      });
    }

    try {
      await interaction.guild.autoModerationRules.create({
        name: "Anti-Mention",
        creatorId: interaction.user.id,
        enabled: true,
        eventType: 1,
        triggerType: 5, // MENTION_SPAM
        triggerMetadata: {
          mentionTotalLimit: 5,
        },
        actions: [
          {
            type: 1,
            metadata: {
              customMessage:
                "🚫 Please avoid mass-mentioning users in this server.",
            },
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setColor("#5FFD0A")
        .setDescription("✅ **Anti-Mention** rule created successfully!");
      return interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content:
          "❌ Failed to create **Anti-Mention** rule. Check my permissions and try again.",
        ephemeral: true,
      });
    }
  }
};
